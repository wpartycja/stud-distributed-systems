#ifndef _SERVICIOS_HELP_H
#define _SERVICIOS_HELP_H 

const char* get_key_str(int key);

const char* get_path(const char* key_str);

int check_size_v1(char *value1);

#endif
